/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrental;
import java.awt.HeadlessException;
import  java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
/**
 *
 * @author USER
 */
public class Customers extends javax.swing.JFrame {

    /**
     * Creates new form Customers
     */
    public Customers() {
        initComponents();
        DisplayCars();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        custP1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        CustIdTb = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        CustPhoneTb = new javax.swing.JTextField();
        SaveBtn = new javax.swing.JButton();
        ResetBtn = new javax.swing.JButton();
        EditBtn = new javax.swing.JButton();
        DeleteBtn = new javax.swing.JButton();
        CustAddTb = new javax.swing.JTextField();
        CustNameTb = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        custP2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        CustomerTable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        CustRent = new javax.swing.JLabel();
        CustCar = new javax.swing.JLabel();
        CustReturn = new javax.swing.JLabel();
        CustLogout = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        custP1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 102), 2));
        custP1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 0));
        jLabel3.setText("  Manage Customers");
        jLabel3.setOpaque(true);
        custP1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 200, 30));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 153, 0));
        jLabel10.setText("Customer ID");
        custP1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));
        custP1.add(CustIdTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 90, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 153, 0));
        jLabel11.setText("Customer Name");
        custP1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 60, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 153, 0));
        jLabel13.setText("Phone");
        custP1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 60, -1, -1));
        custP1.add(CustPhoneTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 90, 100, -1));

        SaveBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        SaveBtn.setForeground(new java.awt.Color(0, 153, 0));
        SaveBtn.setText("Save");
        SaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBtnActionPerformed(evt);
            }
        });
        custP1.add(SaveBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 70, -1));

        ResetBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ResetBtn.setForeground(new java.awt.Color(0, 153, 51));
        ResetBtn.setText("Reset");
        ResetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetBtnActionPerformed(evt);
            }
        });
        custP1.add(ResetBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, -1, -1));

        EditBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        EditBtn.setForeground(new java.awt.Color(0, 153, 0));
        EditBtn.setText("Edit");
        EditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBtnActionPerformed(evt);
            }
        });
        custP1.add(EditBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, 70, -1));

        DeleteBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        DeleteBtn.setForeground(new java.awt.Color(0, 153, 0));
        DeleteBtn.setText("Delete");
        DeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBtnActionPerformed(evt);
            }
        });
        custP1.add(DeleteBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, -1, -1));
        custP1.add(CustAddTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 100, -1));
        custP1.add(CustNameTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, 100, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(51, 153, 0));
        jLabel14.setText("Address");
        custP1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 60, -1, -1));

        getContentPane().add(custP1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 30, 580, 230));

        custP2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 255, 102), 2));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 153, 51));
        jLabel8.setText("Customers List");
        jLabel8.setOpaque(true);

        CustomerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Customer ID", "Customer Name", "Address", "Phone"
            }
        ));
        CustomerTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(CustomerTable);

        javax.swing.GroupLayout custP2Layout = new javax.swing.GroupLayout(custP2);
        custP2.setLayout(custP2Layout);
        custP2Layout.setHorizontalGroup(
            custP2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, custP2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(219, 219, 219))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 576, Short.MAX_VALUE)
        );
        custP2Layout.setVerticalGroup(
            custP2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(custP2Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
        );

        getContentPane().add(custP2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 270, 580, 160));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setOpaque(true);
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 0, 760, 26));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 0, 0));
        jLabel9.setText("  X");
        jLabel9.setOpaque(true);
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 0, 30, 26));

        jPanel1.setBackground(new java.awt.Color(0, 204, 51));

        CustRent.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        CustRent.setForeground(new java.awt.Color(255, 255, 255));
        CustRent.setText("  Rents");
        CustRent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustRentMouseClicked(evt);
            }
        });

        CustCar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        CustCar.setForeground(new java.awt.Color(255, 255, 255));
        CustCar.setText("Cars");
        CustCar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustCarMouseClicked(evt);
            }
        });

        CustReturn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        CustReturn.setForeground(new java.awt.Color(255, 255, 255));
        CustReturn.setText("Returns");
        CustReturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustReturnMouseClicked(evt);
            }
        });

        CustLogout.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        CustLogout.setForeground(new java.awt.Color(255, 255, 255));
        CustLogout.setText("jLabel1");
        CustLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustLogoutMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addComponent(CustLogout)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CustReturn)
                    .addComponent(CustRent)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(CustCar)))
                .addGap(56, 56, 56))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(CustCar)
                .addGap(18, 18, 18)
                .addComponent(CustRent)
                .addGap(43, 43, 43)
                .addComponent(CustReturn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                .addComponent(CustLogout)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 190, 410));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    Connection Con=null;
    Statement St = null;
    java.sql.ResultSet Rs = null;
    
    
    private void DisplayCars()
{
    try{
        Con = DriverManager.getConnection("Jdbc:mysql://localhost/cardb","root","");
        St = Con.createStatement();
        Rs = St.executeQuery("select * from customertbl");
        CustomerTable.setModel(DbUtils.resultSetToTableModel(Rs));
        System.out.println("select * from cartbl executed........!!!");
    }catch(SQLException e)
    {
        e.printStackTrace();
    }
}
    
    
    private void SaveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBtnActionPerformed
     if(CustIdTb.getText().isEmpty() ||CustNameTb.getText().isEmpty() ||CustAddTb.getText().isEmpty() || CustPhoneTb.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Missing Information");
        }
        else{
        try{
            Con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/cardb","root","");
           // PreparedStatement  add = Con.prepareStatement("insert into cartbl values('"+RegNumTb.getText()+"','"+BrandTb.getText()+"','"++"',"","++","++""));
           PreparedStatement  add = Con.prepareStatement("insert into customertbl values(?,?,?,?)");
            add.setString(1,CustIdTb.getText());
            add.setString(2, CustNameTb.getText());
            add.setString(3, CustAddTb.getText());
            add.setString(4, CustPhoneTb.getText());
           
            int row = add.executeUpdate();
            JOptionPane.showMessageDialog(this, "Customer Added Successfully.");
           DisplayCars();
            
      
        }catch(Exception e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error :"+e.toString());
        }
    }        
        
    }//GEN-LAST:event_SaveBtnActionPerformed

    
     private void Reset()
    {
        CustIdTb.setText("");
        CustNameTb.setText("");
        CustAddTb.setText("");
        CustPhoneTb.setText("");
    }
    
    
    private void ResetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetBtnActionPerformed
        
        Reset();
        
        
        
    }//GEN-LAST:event_ResetBtnActionPerformed

    private void CustomerTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerTableMouseClicked
         DefaultTableModel model = (DefaultTableModel)CustomerTable.getModel();
       int MyIndex = CustomerTable.getSelectedRow();
       CustIdTb.setText(model.getValueAt(MyIndex,0).toString());
       CustNameTb.setText(model.getValueAt(MyIndex,1).toString());
       CustAddTb.setText(model.getValueAt(MyIndex,2).toString());
       CustPhoneTb.setText(model.getValueAt(MyIndex,3).toString());
    }//GEN-LAST:event_CustomerTableMouseClicked

    private void DeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBtnActionPerformed
       
        
         if(CustIdTb.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Select the Customer to be deleted.");
        }
        else{
        try{
            Con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/cardb","root","");
           int id = Integer.valueOf(CustIdTb.getText());
           String Query = "Delete from customertbl where CustId ='"+id+"' ";
           //PreparedStatement  add = Con.prepareStatement();
           Statement Add = Con.createStatement();
           Add.executeUpdate(Query);
           JOptionPane.showMessageDialog(this, "Customer Deleted Successfully.");
           DisplayCars();
             Reset();
            
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Error : sql exception \n "+ex.toString());
        }catch(HeadlessException | NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null, "Error :"+e.toString());
            e.printStackTrace();
            
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        }
        
        
    }//GEN-LAST:event_DeleteBtnActionPerformed

    private void EditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBtnActionPerformed
        
         if(CustIdTb.getText().isEmpty() ||CustNameTb.getText().isEmpty() ||CustAddTb.getText().isEmpty() || CustPhoneTb.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Select the customer to be Updated.");
        }
        else{
        try{
            Con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/cardb","root","");
           // PreparedStatement  add = Con.prepareStatement("insert into cartbl values('"+RegNumTb.getText()+"','"+BrandTb.getText()+"','"++"',"","++","++""));  another way LIKE THAT
           String CustId = CustIdTb.getText();
           String Query = "Update customertbl set CustName ='"+CustNameTb.getText()+"',CustAdd='"+CustAddTb.getText()+"',CustPhone="+CustPhoneTb.getText()+" where CustId="+CustId+"  ";
          // String Query = "Update root.cartbl set Brand ='"+BrandTb.getText()+"',Model='"+ModelTb.getText()+"',Status='"+StatusCb.getSelectedItem().toString()+"',Price="+PriceTb.getText()+"where CarReg ='"+Req+"'" ;
           //PreparedStatement  add = Con.prepareStatement();
           Statement Add = Con.createStatement();
           Add.executeUpdate(Query);
           JOptionPane.showMessageDialog(this, "Car Updated Successfully.");
           DisplayCars();
           Reset();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Cars.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Error : sql exception \n "+ex.toString());
        }
        
        
    }//GEN-LAST:event_EditBtnActionPerformed
    }
    private void CustRentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustRentMouseClicked
        new Rents().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_CustRentMouseClicked

    private void CustCarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustCarMouseClicked
        new Cars().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_CustCarMouseClicked

    private void CustReturnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustReturnMouseClicked
        new Returns().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_CustReturnMouseClicked

    private void CustLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustLogoutMouseClicked
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_CustLogoutMouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel9MouseClicked
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Customers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CustAddTb;
    private javax.swing.JLabel CustCar;
    private javax.swing.JTextField CustIdTb;
    private javax.swing.JLabel CustLogout;
    private javax.swing.JTextField CustNameTb;
    private javax.swing.JTextField CustPhoneTb;
    private javax.swing.JLabel CustRent;
    private javax.swing.JLabel CustReturn;
    private javax.swing.JTable CustomerTable;
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JButton EditBtn;
    private javax.swing.JButton ResetBtn;
    private javax.swing.JButton SaveBtn;
    private javax.swing.JPanel custP1;
    private javax.swing.JPanel custP2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
