/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrental;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author USER
 */
public class Rents extends javax.swing.JFrame {

    /**
     * Creates new form Rents
     */
    public Rents() {
        initComponents();
        DisplayCars();
        GetCustomers();
        DisplayRents();
        
    }

   Connection Con=null;
Statement St = null;
java.sql.ResultSet Rs = null;
 

private void DisplayCars()
{
    String CarStatus = "Available";
    try{
        Con = DriverManager.getConnection("Jdbc:mysql://localhost/cardb","root","");
        St = Con.createStatement();
        Rs = St.executeQuery("select * from cartbl where status = '"+CarStatus+"'");
        CarsTable.setModel(DbUtils.resultSetToTableModel(Rs));
        System.out.println("select * from cartbl executed........!!!");
    }catch(SQLException e)
    {
        e.printStackTrace();
    }
}


private void DisplayRents()
{
    String CarStatus = "Available";
    try{
        Con = DriverManager.getConnection("Jdbc:mysql://localhost/cardb","root","");
        St = Con.createStatement();
        Rs = St.executeQuery("select * from renttbl");
        RentTable.setModel(DbUtils.resultSetToTableModel(Rs));
        System.out.println("select * from cartbl executed........!!!");
    }catch(SQLException e)
    {
        e.printStackTrace();
    }
}



private void GetCustomers()
{
    try{
        
        Con = DriverManager.getConnection("Jdbc:mysql://localhost/cardb","root","");
        St = Con.createStatement();
        String query = "select * from customertbl";
        Rs = St.executeQuery(query);
         while(Rs.next()){
             String Customer = Rs.getString("CustName");
             CustCb.addItem(Customer);
         }
        
       }catch(Exception e){
    e.printStackTrace();
}
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        GoToReturn = new javax.swing.JLabel();
        GoToCustomer = new javax.swing.JLabel();
        GoToLogin = new javax.swing.JLabel();
        GoToCar = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        RentIdTb = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        RegNumTb = new javax.swing.JTextField();
        FeeTb = new javax.swing.JTextField();
        CustCb = new javax.swing.JComboBox<>();
        ReturnDate = new com.toedter.calendar.JDateChooser();
        RentDate = new com.toedter.calendar.JDateChooser();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        CarsTable = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        ResetBtn = new javax.swing.JButton();
        PrintBtn = new javax.swing.JButton();
        EditBtn = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        SaveBtn1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        RentTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 204, 0));

        GoToReturn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        GoToReturn.setForeground(new java.awt.Color(255, 255, 255));
        GoToReturn.setText("Return Cars");
        GoToReturn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GoToReturnMouseClicked(evt);
            }
        });

        GoToCustomer.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        GoToCustomer.setForeground(new java.awt.Color(255, 255, 255));
        GoToCustomer.setText("Customers");
        GoToCustomer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GoToCustomerMouseClicked(evt);
            }
        });

        GoToLogin.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        GoToLogin.setForeground(new java.awt.Color(255, 255, 255));
        GoToLogin.setText("Logout");
        GoToLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GoToLoginMouseClicked(evt);
            }
        });

        GoToCar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        GoToCar.setForeground(new java.awt.Color(255, 255, 255));
        GoToCar.setText("   Cars");
        GoToCar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GoToCarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(GoToReturn)
                        .addGap(0, 40, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(GoToCustomer)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(GoToLogin)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(GoToCar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(186, Short.MAX_VALUE)
                .addComponent(GoToCar)
                .addGap(47, 47, 47)
                .addComponent(GoToCustomer)
                .addGap(54, 54, 54)
                .addComponent(GoToReturn)
                .addGap(143, 143, 143)
                .addComponent(GoToLogin)
                .addGap(22, 22, 22))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 540));

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 0, 0));
        jLabel9.setText(" X");
        jLabel9.setOpaque(true);
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 0, 30, 30));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setOpaque(true);
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 680, 30));

        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 51), 2));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 51));
        jLabel3.setText("  Cars On Rent");
        jLabel3.setOpaque(true);
        jPanel5.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 320, 150, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 153, 0));
        jLabel11.setText("Rent ID");
        jPanel5.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));
        jPanel5.add(RentIdTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 80, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 153, 0));
        jLabel13.setText("Registration");
        jPanel5.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 70, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(51, 153, 0));
        jLabel14.setText("Fees");
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 60, -1, -1));
        jPanel5.add(RegNumTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 90, -1));
        jPanel5.add(FeeTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 90, 70, 20));

        jPanel5.add(CustCb, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 90, 90, -1));
        jPanel5.add(ReturnDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, -1, -1));

        RentDate.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jPanel5.add(RentDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 90, -1, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(51, 153, 0));
        jLabel16.setText("Customer name");
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 60, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 153, 0));
        jLabel17.setText("Return Date");
        jPanel5.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 60, -1, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(51, 153, 0));
        jLabel18.setText("Rent Date");
        jPanel5.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 60, -1, -1));

        CarsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CARREG", "BRAND", "MODEL", "STATUS", "PRICE"
            }
        ));
        CarsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CarsTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(CarsTable);

        jPanel5.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 650, 90));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 0));
        jLabel7.setText("  Cars Rental");
        jLabel7.setOpaque(true);
        jPanel5.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, 130, 30));

        ResetBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ResetBtn.setForeground(new java.awt.Color(51, 153, 0));
        ResetBtn.setText("Reset");
        ResetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetBtnActionPerformed(evt);
            }
        });
        jPanel5.add(ResetBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 130, 90, 30));

        PrintBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        PrintBtn.setForeground(new java.awt.Color(0, 204, 51));
        PrintBtn.setText("Print");
        PrintBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintBtnActionPerformed(evt);
            }
        });
        jPanel5.add(PrintBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 450, 80, 30));

        EditBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        EditBtn.setForeground(new java.awt.Color(0, 153, 0));
        EditBtn.setText("Edit");
        EditBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditBtnActionPerformed(evt);
            }
        });
        jPanel5.add(EditBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, 80, 30));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 153, 0));
        jLabel4.setText("  Cars List");
        jLabel4.setOpaque(true);
        jPanel5.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 180, 100, 30));

        SaveBtn1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        SaveBtn1.setForeground(new java.awt.Color(51, 153, 0));
        SaveBtn1.setText("Save");
        SaveBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveBtn1ActionPerformed(evt);
            }
        });
        jPanel5.add(SaveBtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 80, 30));

        RentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null}
            },
            new String [] {
                "RENTID", "CARREG", "CUSTOMER", "RENTDATE", "RETURNDATE", "RENT FEE"
            }
        ));
        RentTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RentTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(RentTable);

        jPanel5.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 650, 80));

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 40, 680, 490));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    private void Reset()
    {
        RentIdTb.setText("");
        RegNumTb.setText("");
        CustCb.setSelectedIndex(-1);
        FeeTb.setText("");
        
    }
    
    private void ResetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetBtnActionPerformed
      Reset();   
      
    }//GEN-LAST:event_ResetBtnActionPerformed

    private void CarsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CarsTableMouseClicked
       
         DefaultTableModel model = (DefaultTableModel)CarsTable.getModel();
       int MyIndex = CarsTable.getSelectedRow();
       RegNumTb.setText(model.getValueAt(MyIndex,0).toString());
     
        
        
    }//GEN-LAST:event_CarsTableMouseClicked

    private void PrintBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintBtnActionPerformed
       
        try{
            RentTable.print();
            
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        
        
        
    }//GEN-LAST:event_PrintBtnActionPerformed

    private void EditBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditBtnActionPerformed
        
           
        if(RegNumTb.getText().isEmpty() ||FeeTb.getText().isEmpty() ||RentIdTb.getText().isEmpty() || RentIdTb.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Select the Rent to be Updated.");
        }
        else{
            
            java.util.Date DateRent = new java.util.Date();
            DateRent = RentDate.getDate();
            java.sql.Date RentDat = new java.sql.Date(DateRent.getDate());
            
            java.util.Date DateRet = new java.util.Date();
            DateRet = ReturnDate.getDate();
            java.sql.Date RetDat = new java.sql.Date(DateRet.getDate());
           
            
        try{
            Con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/cardb","root","");
           // PreparedStatement  add = Con.prepareStatement("insert into cartbl values('"+RegNumTb.getText()+"','"+BrandTb.getText()+"','"++"',"","++","++""));  another way LIKE THAT
           int RId = Integer.valueOf(RentIdTb.getText());
           String Query = "Update Renttbl set CarReg ='"+RegNumTb.getText()+"',CustName='"+CustCb.getSelectedItem().toString()+"',RentDate='"+RentDat+"',ReturnDate="+RetDat+" RentFee="+FeeTb.getText()+"  where RentId = "+RId+"";
          // String Query = "Update root.cartbl set Brand ='"+BrandTb.getText()+"',Model='"+ModelTb.getText()+"',Status='"+StatusCb.getSelectedItem().toString()+"',Price="+PriceTb.getText()+"where CarReg ='"+Req+"'" ;
           //PreparedStatement  add = Con.prepareStatement();
           Statement Add = Con.createStatement();
           Add.executeUpdate(Query);
           JOptionPane.showMessageDialog(this, "Rent Derails Updated Successfully.");
           DisplayCars();
           Reset();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Cars.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Error : sql exception \n "+ex.toString());
        }catch(HeadlessException | NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null, "Error :"+e.toString());
            
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        }
        
        
    }//GEN-LAST:event_EditBtnActionPerformed

    private void SaveBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveBtn1ActionPerformed
       
        
         if(RegNumTb.getText().isEmpty() ||FeeTb.getText().isEmpty() ||RentIdTb.getText().isEmpty() || RentIdTb.getText().isEmpty()){
            JOptionPane.showMessageDialog(this,"Missing Information");
        }
        else{
        try{
            java.util.Date DateRent = new java.util.Date();
            DateRent = RentDate.getDate();
            java.sql.Date RentDat = new java.sql.Date(DateRent.getDate());
            
            java.util.Date DateRet = new java.util.Date();
            DateRet = ReturnDate.getDate();
            java.sql.Date RetDat = new java.sql.Date(DateRet.getDate());
            
            Con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/cardb","root","");
           // PreparedStatement  add = Con.prepareStatement("insert into cartbl values('"+RegNumTb.getText()+"','"+BrandTb.getText()+"','"++"',"","++","++""));
           PreparedStatement  add = Con.prepareStatement("insert into Renttbl values(?,?,?,?,?,?)");
            add.setInt(1,Integer.valueOf(RentIdTb.getText()));
            add.setString(2, RegNumTb.getText());
            add.setString(3, CustCb.getSelectedItem().toString());
            add.setDate(4,RentDat);  
            add.setDate(5,RetDat); 
            add.setInt(6, Integer.valueOf(FeeTb.getText()));
            int row = add.executeUpdate();
            JOptionPane.showMessageDialog(this, "Car Rentered Successfully.");
            DisplayRents();
            
        } catch (SQLException ex) {
            //Logger.getLogger(Cars.class.getName()).log(Level.SEVERE, null, ex);
             JOptionPane.showMessageDialog(null, "Error : sql exception \n "+ex.toString());
            // ex.printStackTrace();
        }catch(HeadlessException | NumberFormatException e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error :"+e.toString());
        }
    }            
        
        
    }//GEN-LAST:event_SaveBtn1ActionPerformed

    private void RentTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RentTableMouseClicked
       
        DefaultTableModel model = (DefaultTableModel)RentTable.getModel();
       int MyIndex = RentTable.getSelectedRow();
       RentIdTb.setText(model.getValueAt(MyIndex,0).toString());
       RegNumTb.setText(model.getValueAt(MyIndex,1).toString());
       CustCb.setSelectedItem(model.getValueAt(MyIndex,2).toString());
       FeeTb.setText(model.getValueAt(MyIndex,5).toString());
      
    }//GEN-LAST:event_RentTableMouseClicked

    private void GoToLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GoToLoginMouseClicked
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_GoToLoginMouseClicked

    private void GoToReturnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GoToReturnMouseClicked
        new Returns().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_GoToReturnMouseClicked

    private void GoToCustomerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GoToCustomerMouseClicked
        new Customers().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_GoToCustomerMouseClicked

    private void GoToCarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GoToCarMouseClicked
        new Cars().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_GoToCarMouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
       System.exit(0);
    }//GEN-LAST:event_jLabel9MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Rents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Rents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Rents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Rents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Rents().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable CarsTable;
    private javax.swing.JComboBox<String> CustCb;
    private javax.swing.JButton EditBtn;
    private javax.swing.JTextField FeeTb;
    private javax.swing.JLabel GoToCar;
    private javax.swing.JLabel GoToCustomer;
    private javax.swing.JLabel GoToLogin;
    private javax.swing.JLabel GoToReturn;
    private javax.swing.JButton PrintBtn;
    private javax.swing.JTextField RegNumTb;
    private com.toedter.calendar.JDateChooser RentDate;
    private javax.swing.JTextField RentIdTb;
    private javax.swing.JTable RentTable;
    private javax.swing.JButton ResetBtn;
    private com.toedter.calendar.JDateChooser ReturnDate;
    private javax.swing.JButton SaveBtn1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables

}