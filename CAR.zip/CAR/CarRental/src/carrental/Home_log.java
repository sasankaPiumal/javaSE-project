
package carrental;


public class Home_log extends javax.swing.JFrame {

   
    public Home_log() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MyProjectcw2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        MyProgressBar = new javax.swing.JProgressBar();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);

        MyProjectcw2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Elephant", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 204, 51));
        jLabel6.setText("CAR RENTAL SOFTWARE");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/carrental/Login.jpg"))); // NOI18N

        MyProgressBar.setBackground(new java.awt.Color(255, 0, 255));
        MyProgressBar.setForeground(new java.awt.Color(11, 247, 43));
        MyProgressBar.setOpaque(true);

        jLabel2.setBackground(new java.awt.Color(204, 255, 255));
        jLabel2.setText("      Geoxia Luxury (Pvt) Ltd...     ");
        jLabel2.setOpaque(true);

        javax.swing.GroupLayout MyProjectcw2Layout = new javax.swing.GroupLayout(MyProjectcw2);
        MyProjectcw2.setLayout(MyProjectcw2Layout);
        MyProjectcw2Layout.setHorizontalGroup(
            MyProjectcw2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MyProjectcw2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(155, 155, 155))
            .addGroup(MyProjectcw2Layout.createSequentialGroup()
                .addGroup(MyProjectcw2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MyProjectcw2Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel6))
                    .addGroup(MyProjectcw2Layout.createSequentialGroup()
                        .addGap(219, 219, 219)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(MyProjectcw2Layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(MyProgressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        MyProjectcw2Layout.setVerticalGroup(
            MyProjectcw2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MyProjectcw2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                .addComponent(MyProgressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel2))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MyProjectcw2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MyProjectcw2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

  
    public static void main(String args[]) {
       
    
        Home_log home = new Home_log();
       home.setVisible(true);
       try{
                for(int a =1; a<=100;a++)
                {
                    Thread.sleep(30);
                    home.MyProgressBar.setValue(a);
                }
    }catch(Exception e)
    {
    }
     new Login().setVisible(true);
     home.dispose();
    
    
    
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar MyProgressBar;
    private javax.swing.JPanel MyProjectcw2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
}
