-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2021 at 05:54 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cardb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cartbl`
--

CREATE TABLE `cartbl` (
  `CarReg` varchar(30) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `Model` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cartbl`
--

INSERT INTO `cartbl` (`CarReg`, `Brand`, `Model`, `Status`, `Price`) VALUES
('17', 'benz', 'fly', 'Booked', 450000),
('3', 'benz', 'AMG', 'Booked', 1),
('4', '5656fgggg', 'AMG', 'Booked', 12),
('5', 'benz', 'AMG', 'Booked', 450000),
('501', 'BMW', 'i8', 'Available', 20),
('51111', 'BMW', 'i8', 'Available', 20),
('511112', 'BMW', 'i8', 'Available', 20),
('6', 'benz', 'AMG', 'Booked', 450000),
('7', 'benz', 'fly', 'Booked', 450000),
('8', 'benz', 'AMG', 'Booked', 450000),
('9', 'benz', 'AMG', 'Available', 500);

-- --------------------------------------------------------

--
-- Table structure for table `customertbl`
--

CREATE TABLE `customertbl` (
  `CustId` int(11) NOT NULL,
  `CustName` varchar(50) NOT NULL,
  `CustAdd` varchar(50) NOT NULL,
  `CustPhone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customertbl`
--

INSERT INTO `customertbl` (`CustId`, `CustName`, `CustAdd`, `CustPhone`) VALUES
(11, 'AMILA', 'AAAAs', '324234'),
(111, 'AMIeq', 'AAAAs', '324234');

-- --------------------------------------------------------

--
-- Table structure for table `renttbl`
--

CREATE TABLE `renttbl` (
  `RentId` int(11) NOT NULL,
  `CarReg` varchar(20) NOT NULL,
  `CustName` varchar(50) NOT NULL,
  `RentDate` date NOT NULL,
  `ReturnDate` date NOT NULL,
  `RentFee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `renttbl`
--

INSERT INTO `renttbl` (`RentId`, `CarReg`, `CustName`, `RentDate`, `ReturnDate`, `RentFee`) VALUES
(1, '511112', 'AMIeq', '1970-01-01', '1970-01-01', 2000),
(115, '51111', 'AMILA', '1970-01-01', '1970-01-01', 43556),
(567, '51111', 'AMILA', '1970-01-01', '1970-01-01', 565666),
(1123, '501', 'AMIeq', '1970-01-01', '1970-01-01', 2000);

-- --------------------------------------------------------

--
-- Table structure for table `returntbl`
--

CREATE TABLE `returntbl` (
  `RetId` int(11) NOT NULL,
  `CarReg` varchar(15) NOT NULL,
  `CustName` varchar(50) NOT NULL,
  `RentDate` date NOT NULL,
  `Delay` int(11) NOT NULL,
  `Fine` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cartbl`
--
ALTER TABLE `cartbl`
  ADD PRIMARY KEY (`CarReg`);

--
-- Indexes for table `customertbl`
--
ALTER TABLE `customertbl`
  ADD PRIMARY KEY (`CustId`);

--
-- Indexes for table `renttbl`
--
ALTER TABLE `renttbl`
  ADD PRIMARY KEY (`RentId`);

--
-- Indexes for table `returntbl`
--
ALTER TABLE `returntbl`
  ADD PRIMARY KEY (`RetId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
